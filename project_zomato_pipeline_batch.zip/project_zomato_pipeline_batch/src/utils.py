from pathlib import Path
from datetime import  datetime
import logging

from anyio.lowlevel import checkpoint

# raw data paths
RAW_BATCH_RESTAURANTS_PATH = Path("./data/raw/batch/zomato_restaurants")
RAW_INTERVAL_ORDERS_PATH = Path("./data/raw/interval/orders")

# processed data paths
PROCESSED_BATCH_ORDER_MATRICS_PATH  = Path("./data/processed/batch/restaurant_matrics")
PROCESSED_INTERVAL_ORDER_METRICS_PATH = Path("./data/processed/interval/restaurant_metrics")
PROCESSED_INTERVAL_RESTAURANT_METRICS_PATH = (
    ".data/processed/interval/restaurant_metrics"
)

# logs path
LOGS_NIFI_PATH = Path("./logs/nifi")
LOGS_AIRFLOW_PATH = Path("./logs/airflow")
LOGS_SPARK_PATH = Path("./logs/spark")

# checkpoints logs
CHECKPOINT_INTERVAL_PIPELINE_PATH = Path("./need to required enter path")

def ensure_required_directories():
    required_dirs = [
        # raw
        RAW_BATCH_RESTAURANTS_PATH,
        RAW_INTERVAL_ORDERS_PATH,

        # processed
        PROCESSED_INTERVAL_ORDER_METRICS_PATH,
        PROCESSED_BATCH_ORDER_MATRICS_PATH,

        # logs
        LOGS_NIFI_PATH,
        LOGS_AIRFLOW_PATH,
        LOGS_SPARK_PATH,

        # checkpoint
        CHECKPOINT_INTERVAL_PIPELINE_PATH

    ]
    for directory in required_dirs:
        directory.mkdir(parents=True,exist_ok=True)

# time utils

def current_utc_timestamp() -> str:
    return datetime.utcnow().isoformat()

def current_date_str() -> str:
    return datetime.utcnow().strftime("%Y-%m-%d")

# checkpointing utilities


def read_checkpoint() -> str |None:
    checkpoint_file = CHECKPOINT_INTERVAL_PIPELINE_PATH /"last_processed.txt"
    if not checkpoint_file.exists():
        return None
    return checkpoint_file.read_text().strip()

def write_checkpoint(value : str):
    CHECKPOINT_INTERVAL_PIPELINE_PATH.mkdir(parents=True,exist_ok=True)
    checkpoint_file = CHECKPOINT_INTERVAL_PIPELINE_PATH / "last_processed.txt"
    checkpoint_file.write_text(value)


def fal_fast(massage:str):
    logging.error(massage)
    raise RuntimeError(massage)





