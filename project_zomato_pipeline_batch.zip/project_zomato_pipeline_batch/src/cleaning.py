from pyspark.sql import DataFrame
from pyspark.sql.functions import col, trim, lower, when, lit


def clean_restaurant_data(df: DataFrame) -> DataFrame:
    cleaned_df = (
        df.dropDuplicates(["restaurant_id"])
        .withColumn("restaurant_name", trim(col("restaurant_name")))
        .withColumn("city", lower(trim(col("city"))))
        .withColumn("cuisine", lower(trim(col("cuisine"))))
        .withColumn(
            "rating",
            when(col("rating").isNull(), lit(0.0))
            .when(col("rating") < 0, lit(0.0))
            .when(col("rating") > 5, lit(5.0))
            .otherwise(col("rating")),
        )
        .withColumn(
            "average_cost_for_two",
            when(col("average_cost_for_two").isNull(), lit(0))
            .when(col("average_cost_for_two") < 0, lit(0))
            .otherwise(col("average_cost_for_two")),
        )
    )
    return cleaned_df


def clean_orders_data(df: DataFrame) -> DataFrame:
    cleaned_df = (
        df.withColumn("city", lower(trim(col("city"))))
        .withColumn(
            "order_value",
            when(col("order_value").isNull(), lit(0.0))
            .when(col("order_value") < 0, lit(0.0))
            .otherwise(col("order_value")),
        )
        .withColumn(
            "rating",
            when(col("rating").isNull(), lit(0.0))
            .when(col("rating") < 0, lit(0.0))
            .when(col("rating") > 5, lit(5.0))
            .otherwise(col("rating")),
        )
    )
    return cleaned_df
