import logging
from pyspark.sql import SparkSession
from pyspark.sql.functions import current_date

from src.utils import (
    RAW_BATCH_RESTAURANTS_PATH,
    RAW_INTERVAL_ORDERS_PATH,
    PROCESSED_BATCH_ORDER_MATRICS_PATH,
    PROCESSED_INTERVAL_ORDER_METRICS_PATH,
    ensure_required_directories
)

from src.validations import (
    validate_interval_orders_file,
    SchemaValidator
)

from src.cleaning import (
    clean_restaurant_data,
    clean_orders_data
)

from src.aggregations import (
    aggregate_restaurant_metrics,
    aggregate_orders_metrics
)

logger = logging.getLogger("spark")


# ---------------- Batch Restaurant Pipeline ----------------
def run_batch_restaurant_pipeline(
    spark: SparkSession,
    schema_file: str
):
    logger.info("Starting batch restaurant pipeline")
    ensure_required_directories()

    # READ RESTAURANT MASTER DATA
    df = (
        spark.read
        .option("header", True)
        .csv(str(RAW_BATCH_RESTAURANTS_PATH))
    )

    logger.info(f"Raw restaurant records: {df.count()}")

    # schema validation (driver-side – OK for demo)
    validator = SchemaValidator(schema_file)

    valid_rows = []
    for row in df.collect():
        record = row.asDict()
        if validator.validate_record(record):
            valid_rows.append(record)

    if not valid_rows:
        raise RuntimeError(
            "No valid restaurant records after validation. "
            "Check RAW_BATCH_RESTAURANTS_PATH and schema mismatch."
        )

    valid_df = spark.createDataFrame(valid_rows)
    logger.info(f"Valid restaurant records: {valid_df.count()}")

    # cleaning
    cleaned_df = clean_restaurant_data(valid_df)

    # add load date
    cleaned_df = cleaned_df.withColumn("load_date", current_date())

    # aggregation
    agg_df = aggregate_restaurant_metrics(cleaned_df)

    # write processed data
    (
        agg_df.write
        .mode("overwrite")
        .partitionBy("city")
        .parquet(str(PROCESSED_BATCH_ORDER_MATRICS_PATH))
    )

    logger.info("Batch restaurant pipeline completed")


# ---------------- Interval Orders Pipeline ----------------
def run_interval_order_pipeline(
    spark: SparkSession,
    json_filename: str,
    schema_filename: str
):
    logger.info("Starting interval order pipeline")
    ensure_required_directories()

    # validate raw order data
    valid_records, invalid_records = validate_interval_orders_file(
        json_filename=json_filename,
        schema_filename=schema_filename
    )

    logger.info(
        f"Order validation summary | "
        f"valid={len(valid_records)} invalid={len(invalid_records)}"
    )

    if not valid_records:
        raise RuntimeError("No valid order records after validation")

    # create dataframe
    df = spark.createDataFrame(valid_records)

    # cleaning
    cleaned_df = clean_orders_data(df)

    # aggregation
    agg_df = aggregate_orders_metrics(cleaned_df)

    # write output
    (
        agg_df.write
        .mode("append")
        .parquet(str(PROCESSED_INTERVAL_ORDER_METRICS_PATH))
    )

    logger.info("Interval order pipeline completed")
