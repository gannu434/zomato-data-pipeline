import json
import logging
from pathlib import Path
from typing import List, Dict, Tuple

from jsonschema import validate, ValidationError

from src.utils import (
    LOGS_SPARK_PATH,
    ensure_required_directories,
    RAW_INTERVAL_ORDERS_PATH,
)

logger = logging.getLogger("validation")

SCHEMA_BASE_PATH = Path("./schemas")


class SchemaValidator:
    def __init__(self, schema_filename: str | Path):
        self.schema_path = SCHEMA_BASE_PATH / schema_filename
        self.schema = self._load_schema()

    def _load_schema(self) -> Dict:
        if not self.schema_path.exists():
            raise FileNotFoundError(f"Schema file not found: {self.schema_path}")

        with open(self.schema_path, "r") as f:
            return json.load(f)

    def validate_record(self, record: Dict) -> bool:
        try:
            validate(instance=record, schema=self.schema)
            return True
        except ValidationError as e:
            logger.error(
                f"Schema validation failed | error={e.message} | record={record}"
            )
            return False

    def validate_records(
        self, records: List[Dict]
    ) -> Tuple[List[Dict], List[Dict]]:
        valid_records, invalid_records = [], []

        for record in records:
            if self.validate_record(record):
                valid_records.append(record)
            else:
                invalid_records.append(record)

        logger.info(
            f"Validation summary | valid={len(valid_records)} invalid={len(invalid_records)}"
        )
        return valid_records, invalid_records


def validate_interval_orders_file(
    json_filename: str,
    schema_filename: str,
) -> Tuple[List[Dict], List[Dict]]:
    ensure_required_directories()

    json_file_path = RAW_INTERVAL_ORDERS_PATH / json_filename
    if not json_file_path.exists():
        raise FileNotFoundError(f"Interval orders file not found: {json_file_path}")

    with open(json_file_path, "r") as f:
        records = json.load(f)

    if not isinstance(records, list):
        raise ValueError(f"Expected list of records in {json_file_path}")

    validator = SchemaValidator(schema_filename)
    return validator.validate_records(records)
