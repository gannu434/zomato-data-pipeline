from pyspark.sql import DataFrame
from pyspark.sql.functions import count, avg, sum as _sum


# batch aggregations (restaurant data)
def aggregate_restaurant_metrics(df: DataFrame) -> DataFrame:
    return (
        df.groupBy("city", "cuisine")
        .agg(
            count("restaurant_id").alias("restaurant_count"),
            avg("rating").alias("avg_rating"),
            avg("average_cost_for_two").alias("avg_cost_for_two"),
        )
    )


# interval aggregations (order data)
def aggregate_orders_metrics(df: DataFrame) -> DataFrame:
    return (
        df.groupBy("city", "cuisine")
        .agg(
            count("order_id").alias("total_orders"),
            _sum("order_value").alias("total_revenue"),
            avg("order_value").alias("avg_order_value"),
            avg("rating").alias("avg_rating"),
        )
    )
