import sys
import logging
import logging.config
import yaml
from pathlib import Path
import os

from pyspark.sql import SparkSession

from src.utils import ensure_required_directories
from src.transformations import (
    run_batch_restaurant_pipeline,
    run_interval_order_pipeline
)

# ---------------- HARD ENV FIX (WINDOWS + SPARK) ----------------
# Completely bypass Hadoop native IO
os.environ.pop("HADOOP_HOME", None)
os.environ.pop("hadoop.home.dir", None)

print("JAVA_HOME:", os.environ.get("JAVA_HOME"))
print("HADOOP_HOME:", os.environ.get("HADOOP_HOME"))
print("hadoop.home.dir:", os.environ.get("hadoop.home.dir"))


# ---------------- LOGGING SETUP ----------------
def setup_logging():
    base_dir = Path(__file__).resolve().parent
    logging_config_path = base_dir / "config" / "logging_config.yaml"

    if not logging_config_path.exists():
        raise FileNotFoundError(f"Logging config not found: {logging_config_path}")

    with open(logging_config_path, "r") as f:
        logging_config = yaml.safe_load(f)

    logging.config.dictConfig(logging_config)


# ---------------- SPARK SESSION ----------------
def create_spark_session(app_name: str) -> SparkSession:
    spark = (
        SparkSession.builder
        .appName(app_name)
        .master("local[*]")
        .config("spark.hadoop.io.native.lib.available", "false")
        .config("spark.hadoop.fs.file.impl", "org.apache.hadoop.fs.LocalFileSystem")
        .config("spark.hadoop.fs.file.impl.disable.cache", "true")
        .config("spark.sql.warehouse.dir", "file:/C:/temp/spark-warehouse")
        .getOrCreate()
    )

    spark.sparkContext.setLogLevel("WARN")
    return spark


# ---------------- MAIN ENTRY ----------------
def main():
    setup_logging()
    logger = logging.getLogger("spark")
    logger.info("starting zomato pipeline")

    try:
        ensure_required_directories()

        spark = create_spark_session("zomatoDataPipeline")

        # batch pipeline
        run_batch_restaurant_pipeline(
            spark=spark,
            schema_file="zomato_restaurants_schema.json"
        )

        # interval pipeline
        run_interval_order_pipeline(
            spark=spark,
            json_filename="zomato_orders_latest.json",
            schema_filename="zomato_orders_schema.json"
        )

        spark.stop()
        logger.info("pipeline execution completed successfully")

    except Exception:
        logger.exception("pipeline execution failed")
        sys.exit(1)


if __name__ == "__main__":
    main()
