from datetime import datetime,timedelta
from airflow import DAG
from airflow.operators.bash import BashOperator

# default Dag args
default_args = {
    "owner" :"data-engineering",
    "depends_on_past":False,
    "email_on_failure": False,
    "email_on_retry":False,
    "retries":2,
    "retry_delay": timedelta(minutes=5),
}

# dag defination
with DAG(
    dag_id = "zomato_data_pipeline",
    default_args=default_args,
    description="zomato batch + interval ETL pipeline",
    schedule_interval = None,
    start_date= datetime(2026,1,1),
    catchup = False,
    tags=["zomato","etl","spark"],
) as dag:

    run_pipeline = BashOperator(
        task_id = "run_zomato_pipeline",
        bash_command= "spark-submit C:/Users/ganesh jauk/PycharmProjects/PythonProject/PythonProject1/etl_practice_projects/project_zomato_pipeline_batch/main.py",
        env = {
            "PYTHONPATH":"C:/Users/ganesh jauk/PycharmProjects/PythonProject/PythonProject1/etl_practice_projects/project_zomato_pipeline_batch"
        },

    )
    run_pipeline